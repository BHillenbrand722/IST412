AlphaCare Use Case 2 Submittion
--------------------------------

For our second use case deliverable, we decided to implement viewing medical records through the main dashboard.
This can be done by going to the medical records tab and clicking on a record ID.
 
As of now, it is impossible to add medical records from any angle, but in the future we plan on having medical personel be able to add medical records for a specific patient. 

So to show off our new future, please use this login information to see what having medical records will look like:

	UN: test
	PW: test

In relation to this login information, we went ahead and serialized the patient list using the GSON library to store it as a text file. This test patient account will
recreate itself if the text file holding the patient list is deleted. 

This was a core refactoring feature we went back and added.

Please let us know if any issues arise with compiling, as they may be related to GSON.

Thank you!