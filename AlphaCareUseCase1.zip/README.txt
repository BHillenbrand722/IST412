AlphaCare Use Case 1 Submittion
--------------------------------

For this use case, we implemented the ability to edit an accounts personal information through the dashboard under the Account pane. 

We also included the ability to create and account and use that newly made account to log in. Accounts are NOT serialized yet, but will be.

Let our group know if there are any issues involving our code or project as a whole. 