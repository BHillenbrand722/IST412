AlphaCare Use Case 3 and 4 
--------------------------------

For our third and fourth use cases, we added the ability to view prescriptions and insurance information from the main dashboard. 
 
Prescriptions would ideally appear when a practicioner prescribes a patient a medication through their portal. But to the see the feature now, please sign in with the test 
account below.

The insurance information tab on the main dashboard allows a patient to see their current medical insurance information. We did not add the ability to edit this information
due to the nature of the information needing to be verified by a medical person. Thus, we assume that to edit this information, you'd need to contact the medical facility.

So to show off our new futures, please use this login information to see prescriptions and insurance information appear in the tabs on the main dashboard.

	UN: test
	PW: test

In relation to this login information, we went ahead and serialized the patient list using the GSON library to store it as a text file. This test patient account will
recreate itself if the text file holding the patient list is deleted. 

Please let us know if any issues arise with compiling, as they may be related to GSON.

Thank you!