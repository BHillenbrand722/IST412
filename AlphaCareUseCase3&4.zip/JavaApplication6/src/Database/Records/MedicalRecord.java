/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database.Records;

import Database.Accounts.Patient;

/**
 *
 * @author bmh5582
 */
public class MedicalRecord {
    String recordID;
    String preExistingConditions; 
    double height;
    double weight;
    String date;
    String description;
    String practicionerNotes;
    String practicioner;
    
    public MedicalRecord( String preExistingConditions, double height, double weight, String date, String description,String practicioner, String practicionerNotes)
    {
        recordID = Integer.toString((int)Math.round(Math.random()*1000000));
        this.preExistingConditions = preExistingConditions;
        this.weight = weight;
        this.height = height; 
        this.date = date;
        this.description = description;
        this.practicioner = practicioner;
        this.practicionerNotes = practicionerNotes;
    }
    
    public String getRecordID(){
        return recordID;
    }
    public String getDate(){
        return date;
    }
    public String getPracticioner(){
        return practicioner;
    }
    public String getDescription(){
        return description;
    }
    public String getHeight(){
        return Double.toString(height);
    }
    public String getWeight(){
        return Double.toString(weight);
    }
    public String getPracticionerNotes(){
        return practicionerNotes;
    }
    public String getPreExistingCond(){
        return preExistingConditions;
    }
}
