/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database.Records;

/**
 *
 * @author bmh5582
 */
public class InsuranceInformation {
    
    private String provider;
    private String idNumber;
    private String groupNumber;
    private String groupName;
    private String policyNum;
    private String primaryHolderFirstName;
    private String primaryHolderLastName;
    private String primaryHolderBirthdate;
    private String primarySSN;
    private String relationship;
    private String primaryPhoneNum;
    private String claimsAddress;
    
    
    
    public InsuranceInformation(
            String provider, String idNumber, String groupNumber, String primaryHolderFirstName, 
            String primaryHolderLastName, String primaryHolderBirthdate, String primarySSN, String relationship,
            String primaryPhoneNum, String claimsAddress, String groupName, String policyNum ){
        this.provider = provider;
        this.idNumber = idNumber;
        this.groupNumber = groupNumber;
        this.primaryHolderFirstName = primaryHolderFirstName;
        this.primaryHolderLastName = primaryHolderLastName;
        this.primaryHolderBirthdate = primaryHolderBirthdate;
        this.primarySSN = primarySSN;
        this.relationship = relationship;
        this.primaryPhoneNum = primaryPhoneNum;
        this.claimsAddress = claimsAddress;
        this.groupName = groupName;
        this.policyNum = policyNum;
    }
    
    public void setProvider(String provider){
        this.provider = provider;
    }
    public void setIDNumber(String idNumber){
        this.idNumber = idNumber;
    }
   public void setGroupNumber(String groupNumber){
        this.groupNumber = groupNumber;
    }
   public void setPrimaryHolderFirstName(String primaryHolderFirstName){
        this.primaryHolderFirstName = primaryHolderFirstName;
    }
   public void setPrimaryHolderLastName(String primaryHolderLastName){
        this.primaryHolderLastName = primaryHolderLastName;
    }
   public void setPrimaryHolderBirthdate(String primaryHolderBirthdate){
        this.primaryHolderBirthdate = primaryHolderBirthdate;
    }
   public void setPrimarySSN(String primarySSN){
        this.primarySSN = primarySSN;
    }
   public void setRelationship(String relationship){
        this.relationship = relationship;
    }
   public void setPrimaryPhoneNum(String primaryPhoneNum){
        this.primaryPhoneNum = primaryPhoneNum;
    }
   public void setClaimsAddress(String claimsAddress){
        this.claimsAddress = claimsAddress;
    }
   public void setGroupName (String groupName ){
        this.groupName  = groupName ;
    }
   public void setPolicyNum (String policyNum ){
        this.policyNum = policyNum ;
    }
    
    public String getProvider(){
        return this.provider;
    }
    public String getIDNumber(){
        return this.idNumber;
    }
   public String getGroupNumber(){
        return this.groupNumber;
    }
   public String getPrimaryHolderFirstName(){
        return this.primaryHolderFirstName;
    }
   public String getPrimaryHolderLastName(){
        return this.primaryHolderLastName;
    }
   public String getPrimaryHolderBirthdate(){
        return this.primaryHolderBirthdate;
    }
   public String getPrimarySSN(){
        String[] ssn = this.primarySSN.split("-");
        return "XXX-XX-" + ssn[2];
    }
   public String getRelationship(){
        return this.relationship;
    }
   public String getPrimaryPhoneNum(){
        return this.primaryPhoneNum;
    }
   public String getClaimsAddress(){
        return this.claimsAddress;
    }
   public String getGroupName(){
        return this.groupName;
    }
   public String getPolicyNum(){
        return this.policyNum;
    }
   
   public String getFullName(){
       return this.primaryHolderFirstName + " " + this.primaryHolderLastName;
   }
   
    
    
}
