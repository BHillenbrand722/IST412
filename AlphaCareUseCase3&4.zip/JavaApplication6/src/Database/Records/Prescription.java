/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database.Records;

/**
 *
 * @author Tom
 */
public class Prescription {
    String date;
    String drugname;
    int strength;
    int quantity;
    String directions;
    String practicioner;
    String registrationNum;
    
    public Prescription(String date, String drugname,int strength, int quantity, String directions,String practicioner, String registrationNum  ){
        this.date = date;
        this.drugname = drugname;
        this.strength = strength;
        this.quantity = quantity;
        this.directions = directions;
        this.practicioner = practicioner;
        this.registrationNum = registrationNum;
    }
    
    public String getDate(){
        return date;
    }
    public String getDrugName(){
        return drugname;
    }
    public String getStrength(){
        return Integer.toString(strength);
    }
    public String getQuantity(){
        return Integer.toString(quantity);
    }
    public String getDirections(){
        return directions;
    }
    public String getPracticioner(){
        return practicioner;
    }
    public String getRegistrationNum(){
        return registrationNum;
    }
}
