/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;

import Database.Accounts.Account;
import Database.Accounts.Patient;
import Database.Records.InsuranceInformation;
import Database.Records.MedicalRecord;
import Database.Records.Prescription;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;

/**
 *
 * @author bmh5582
 */
public class MainModel {

  //Will create list or sometime of storage of accounts here.
  public ArrayList<Database.Accounts.Patient> patientList;
  
  //Singleton Design Pattern Part 1
  private static ArrayList<Database.Accounts.HospitalAdministrator> hospitalAdministratorList;
  
  public Database.Accounts.Patient currentUserPatient;
  public int throwaway;
  
  Gson gson = new Gson();
  public String json;
  Type patientListType = new TypeToken<ArrayList<Database.Accounts.Patient>>() {}.getType();
  
  public MainModel(){
      //Attempt patient list loading.
        try{
            patientList = this.deserializationPatientList();
            if(patientList == null){
                patientList = new ArrayList<Database.Accounts.Patient>();
                
                //TEST PATIENT CREATION
                Account testAccount = new Account("test", "test", "patient");
                patientList.add(new Patient(testAccount, 1001));
                patientList.get(0).getMedicalRecords().add(new MedicalRecord(
                    "Depression, Extreme Obesity, Acne", 72.00, 400.00, "2019-11-24", "Issues with acne and joint pain.", "Dr.Example", "Recommended patient focus on weight loss for joint pain and prescribed acne ointment. Prescribed Isotretinoin."
                ));
                patientList.get(0).getMedicalRecords().add(new MedicalRecord(
                    "Depression, Extreme Obesity", 72.00, 400.00, "2020-02-04", "Checkup from previous visit.", "Dr.Example", "Acne has been elimated from medication, but obesity still the same. Recommending a diet specialist to assist with weight loss and prescribing Phentermine and Topiramate."
                ));
                patientList.get(0).getMedicalRecords().add(new MedicalRecord(
                    "Depression", 72.00, 250.00, "2020-10-27", "Checkup from previous visit.", "Dr.Example", "Diet specialist has been working with patient with weight issues. Joint pain has seem to have been eliminated after losing 150 pounds over the course of 8 months."
                ));
                //
                patientList.get(0).getCurrentRXs().add(new Prescription(
                    "2019-11-24", "Isotretinoin", 100, 40, "Swallow capsules whole. Twice daily for 15-20 weeks. Take with food.", "Dr.Example", "AT1234567"
                ));
                patientList.get(0).getCurrentRXs().add(new Prescription(
                    "2020-02-04", "Phentermine and Topiramate", 70, 30, "Swallow capsules whole. Twice daily for 15 weeks. Take with food.", "Dr.Example", "RT7654321"
                ));
                //
                patientList.get(0).setInsuranceInformation(new InsuranceInformation(
                    "Blue Cross Blue Shield", "K67531234", "55005500", "test", "testlastname", "1999-12-31", "123-45-6789", "Holder", "(343) 564-1234", "1234 BlueCross Dr. Rochester, NY 131313", "Basic", "134589"  
                ));
                
                this.serializationPatientList();
            }
        }
        catch(IOException e){
            patientList = new ArrayList<Database.Accounts.Patient>();
            
        }
  }
  
  public ArrayList<Database.Accounts.Patient> getPatientList(){
      return patientList; 
  }
  
  public String authenticatePatient(String un, String pw){
      
      for(int i = 0; i< getPatientList().size(); i++){
        if(getPatientList().get(i).getAccount().getUsername().equals(un)){
            if(getPatientList().get(i).getAccount().getPassword().equals(pw)){
                throwaway = i;
                return "Login Successful";
            }
        }
      }
      return "Login Invalid";
  }
  
  public void addNewPatient(String newU, String newP, String type){
      int accountnum = (int) (Math.random() * 100000);
      Database.Accounts.Account newaccount = new Database.Accounts.Account(newU, newP, type);
      Database.Accounts.Patient newpatient = new Database.Accounts.Patient(newaccount, accountnum);
      getPatientList().add(newpatient);
      
  }
  
  public void setCurrentUserPatient(){
      currentUserPatient = getPatientList().get(throwaway);
  }
  
  public Patient getCurrentUserPatient(){
      return currentUserPatient;
  }
  
  //Singleton Design Pattern Part 2
  public static ArrayList<Database.Accounts.HospitalAdministrator> getHospitalAdministratorList(){
      return  hospitalAdministratorList;
  }
  
  public void serializationPatientList(){
        json = gson.toJson(this.getPatientList());
        try{
            FileWriter fw = new FileWriter("patientlist.txt");
            fw.write(json);
            fw.close();
            System.out.println(json);
        }
        catch(IOException n){
            System.out.println("Could not write patientlist.txt");
        }
    }
    
    public ArrayList<Database.Accounts.Patient> deserializationPatientList() throws FileNotFoundException, IOException{
        try{
            
            FileReader fr = new FileReader("patientlist.txt");
            BufferedReader inputFile =new BufferedReader(fr);
            json = inputFile.readLine();
            fr.close();
        }
        catch(FileNotFoundException n){
            System.out.println("Failed to read patientlist.txt");
        }
        System.out.println(json);
        return gson.fromJson(json, patientListType);
    }



}