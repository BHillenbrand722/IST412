/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.RadioButton;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;

/**
 *
 * @author Tom
 */
public class InsuranceInfoViewCont implements Initializable {
    @FXML RadioButton holderInfoToggle;
    @FXML Text providerText;
    @FXML Text claimsaddressText;
    @FXML Text policynumberText;
    @FXML Text groupnameText;
    @FXML Text groupidText;
    @FXML Text fullnameText;
    @FXML Text phonenumText;
    @FXML Text ssnText;
    @FXML Text relationshipText;
    @FXML Text memberidText;
    @FXML Pane holderInfoPane;
    
    public MainDashboardViewController theParentCont;
    public InsuranceInfoViewCont(MainDashboardViewController incoming){
        theParentCont = incoming;
    }
    
    public void initialize() {
        this.providerText.setText(theParentCont.theParentCont.getMainModel().getCurrentUserPatient().getInsuranceInformation().getProvider());
        this.claimsaddressText.setText(theParentCont.theParentCont.getMainModel().getCurrentUserPatient().getInsuranceInformation().getClaimsAddress());
        this.policynumberText.setText(theParentCont.theParentCont.getMainModel().getCurrentUserPatient().getInsuranceInformation().getPolicyNum());
        this.groupidText.setText(theParentCont.theParentCont.getMainModel().getCurrentUserPatient().getInsuranceInformation().getIDNumber());
        this.groupnameText.setText(theParentCont.theParentCont.getMainModel().getCurrentUserPatient().getInsuranceInformation().getGroupName());
    }   
    //Show holder information
    @FXML public void showHolderInfo(){
       
        if(this.holderInfoPane.visibleProperty().getValue() == false){
            //
            fullnameText.setText(theParentCont.theParentCont.getMainModel().getCurrentUserPatient().getInsuranceInformation().getFullName());
            phonenumText.setText(theParentCont.theParentCont.getMainModel().getCurrentUserPatient().getInsuranceInformation().getPrimaryPhoneNum());
            ssnText.setText(theParentCont.theParentCont.getMainModel().getCurrentUserPatient().getInsuranceInformation().getPrimarySSN());
            relationshipText.setText(theParentCont.theParentCont.getMainModel().getCurrentUserPatient().getInsuranceInformation().getRelationship());
            memberidText.setText(theParentCont.theParentCont.getMainModel().getCurrentUserPatient().getInsuranceInformation().getIDNumber());
            this.holderInfoPane.setStyle("-fx-background-color: aliceblue");
            this.holderInfoPane.setVisible(true);
        }
        else{
            this.holderInfoPane.setVisible(false);
        }
        
    }
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
            this.providerText.setText(theParentCont.theParentCont.getMainModel().getCurrentUserPatient().getInsuranceInformation().getProvider());
            this.claimsaddressText.setText(theParentCont.theParentCont.getMainModel().getCurrentUserPatient().getInsuranceInformation().getClaimsAddress());
            this.policynumberText.setText(theParentCont.theParentCont.getMainModel().getCurrentUserPatient().getInsuranceInformation().getPolicyNum());
            this.groupidText.setText(theParentCont.theParentCont.getMainModel().getCurrentUserPatient().getInsuranceInformation().getIDNumber());
            this.groupnameText.setText(theParentCont.theParentCont.getMainModel().getCurrentUserPatient().getInsuranceInformation().getGroupName());
        
    }
    
}
