
package View;

import Database.Accounts.Account;
import Database.Accounts.Patient;
import Database.Records.MedicalRecord;
import java.io.IOException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;

/**
 *
 * @author sound
 */
public class MedicalRecordController {
    
    @FXML Button backToDashboardButton;
    @FXML Text recordIDtxt;
    @FXML Text recordDatetxt;
    @FXML Text recordPracticionertxt;
    @FXML Text recordHeighttxt;
    @FXML Text recordWeighttxt;
    @FXML Text recordConditionstxt;
    @FXML AnchorPane informationTab;
    @FXML Text recordDescriptiontxt;
    @FXML Text recordPNotestxt;
    
     MainDashboardViewController theParentCont;
     String recordID;
     public MedicalRecordController(MainDashboardViewController incoming, String incomingRecordID){
         theParentCont = incoming;
         recordID = incomingRecordID;
     }
     
     @FXML public void backToDashboard() throws IOException{
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/mainDashboardView.fxml"));
        MainDashboardViewController controller = new MainDashboardViewController(theParentCont.theParentCont);
        loader.setController(controller);
        Parent root = loader.load();
        backToDashboardButton.getScene().setRoot(root);
    }
     
    @FXML public void setupAllTabs(){
        Database.Records.MedicalRecord tempRec = this.theParentCont.theParentCont.getMainModel().getCurrentUserPatient().getMedicalRecordbyID(recordID);
        
        //Set all text objects to desired record.
        recordIDtxt.setText(tempRec.getRecordID());
        recordDatetxt.setText(tempRec.getDate());
        recordPracticionertxt.setText(tempRec.getPracticioner());
        recordHeighttxt.setText(tempRec.getHeight());
        recordWeighttxt.setText(tempRec.getWeight());
        recordConditionstxt.setText(tempRec.getPreExistingCond());
        recordPNotestxt.setText(tempRec.getPracticionerNotes());
        recordDescriptiontxt.setText(tempRec.getDescription());
    }
}
