
package View;

import Application.CreateAccountController;
import Database.Records.Prescription;
import java.io.IOException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Accordion;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TitledPane;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;


public class MainDashboardViewController {

    
    AdministatorView administatorView;
    MedicalRecordView medicalRecordView;
    PersonalPortalViewController personalPortalView;
    MainMenuView mainMenuView;
    Application.MainController theParentCont;
    
    @FXML Button logoutBtn;
    @FXML Text usernameText;
    @FXML AnchorPane accountAPane;
    @FXML TitledPane accountPane; 
    @FXML Button editInfoButton;
    @FXML Text accountTypeText;
    @FXML TableView<Database.Records.MedicalRecord> recordTable;
    @FXML TableColumn<Database.Records.MedicalRecord, String> recordID;
     @FXML TableColumn<Database.Records.MedicalRecord, String> recordDate;
      @FXML TableColumn<Database.Records.MedicalRecord, String> recordPracticioner;
       @FXML TableColumn<Database.Records.MedicalRecord, String> recordDes;
    @FXML Tab medicalRecordsTab;
    @FXML Accordion prescriptList;
    @FXML Tab insuranceInfoTab;
    @FXML AnchorPane insuranceInfo;
    
    
    public MainDashboardViewController(Application.MainController incoming){
      theParentCont = incoming;
    }
    
    
    @FXML public void logoutToLogin() throws IOException{
        
    }
    
    @FXML public void setUsernameText(){
        usernameText.setText(theParentCont.getMainModel().getCurrentUserPatient().getAccount().getUsername());
        accountTypeText.setText(theParentCont.getMainModel().getCurrentUserPatient().getAccount().getType());
    }
    
    @FXML public void moveToPersonalInfo() throws IOException{
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/personalPortalView.fxml"));
        PersonalPortalViewController controller = new PersonalPortalViewController(this);
        loader.setController(controller);
        Parent root = loader.load();
        editInfoButton.getScene().setRoot(root);
    }
    
    public AdministatorView getAdministatorView(){
      return administatorView;
    }

    public MedicalRecordView getMedicalRecordView(){
      return medicalRecordView;
    }

    public PersonalPortalViewController getPersonalPortalView(){
      return personalPortalView;
    }

    public MainMenuView getMainMenuView(){
      return mainMenuView;
    }
    
    //Loads any and all records for a patient's viewing.
    @FXML public void loadRecords(){
        recordID.setCellValueFactory(new PropertyValueFactory<Database.Records.MedicalRecord, String>("recordID"));
        recordID.setCellFactory(tc -> {
            TableCell<Database.Records.MedicalRecord, String> cell = new TableCell<Database.Records.MedicalRecord, String>() {
                @Override
                protected void updateItem(String item, boolean empty) {
                    super.updateItem(item, empty) ;
                    setText(empty ? null : item);
                    this.setTextFill(Color.BLUEVIOLET);
                }
            };
            cell.setOnMouseClicked(e -> {
                if (! cell.isEmpty()) {
                    String recordId = cell.getText();
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/medicalRecordView.fxml"));
                    MedicalRecordController controller = new MedicalRecordController(this, recordId);
                    loader.setController(controller);
                    try{
                    Parent root = loader.load();
                    editInfoButton.getScene().setRoot(root);
                    }
                    catch(IOException fudge){
                        System.out.println("Failed to move to medical record view!");
                    }
                }
            });
            return cell ;
        });
        recordDate.setCellValueFactory(new PropertyValueFactory<Database.Records.MedicalRecord, String>("date"));
        recordPracticioner.setCellValueFactory(new PropertyValueFactory<Database.Records.MedicalRecord, String>("practicioner"));
        recordDes.setCellValueFactory(new PropertyValueFactory<Database.Records.MedicalRecord, String>("description"));
        ObservableList recordList = FXCollections.observableList(theParentCont.getMainModel().getCurrentUserPatient().getMedicalRecords());
        recordTable.setItems(recordList);
    }
    
    //Load precriptions for a user's viewing.
    @FXML public void loadPrescriptions(){
        //
        prescriptList.getPanes().clear();
        int i = 0;
        for (Prescription currentRX : this.theParentCont.getMainModel().currentUserPatient.getCurrentRXs()) {
            i += 1;
             AnchorPane newPanelContent = new AnchorPane();
             newPanelContent.getChildren().add(new Label(
                     "Date Prescribed: " + currentRX.getDate() + "\n\n" +
                     "Drug Name: " + currentRX.getDrugName() + "\n\n" +
                     "Strength: " + currentRX.getStrength() + " mg" + "\n\n" +
                     "Quantity: " + currentRX.getQuantity() + "\n\n" +
                     "Prescribed By: " + currentRX.getPracticioner() + "\n\n" +
                     "Use Directions: " + currentRX.getDirections() + "\n\n" +
                     "Registration Number: " + currentRX.getRegistrationNum() + "\n\n"
             
             ));
             

             TitledPane pane = new TitledPane("RX " + i, newPanelContent);
             prescriptList.getPanes().add(pane);
             
        }
    }
    
    //Load insurance info view within tab.
    @FXML public void loadInsuranceInfo() throws IOException{
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/insuranceInfoView.fxml"));
        InsuranceInfoViewCont controller = new InsuranceInfoViewCont (this);
        loader.setController(controller);
        Pane newpane = loader.load();
        
        insuranceInfo.getChildren().add(newpane);
    }
}

