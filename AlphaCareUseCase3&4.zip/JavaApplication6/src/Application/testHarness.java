/**
This is an excutable class that when ran will instantiate a test controller.
*/

public class testHarness{

  public static void main(String[] args){
    testController tc = new testController();
  }
}
