package Database.Accounts;

import java.io.StringBufferInputStream;

public class Account {
    
    private String username;
    private String password;
    private String type;
    
    //private Account(String username, String password){
   //     this.username = username;
   //     this.password = password;
   // }
    
    public Account(String username, String password, String type){
        this.username = username;
        this.password = encrypt(password, 2);
        this.type = type;
    }
    //setters
    private void setUsername(String username){
        this.username = username;
    }
    private void setPassword(String password){
        this.password = password;
    }
    private void setType(String type){
        this.type = type;
    }
    //getters
    public String getUsername(){
        return this.username;
    }
    public String getPassword(){
        return this.password;
    }
    public String getType(){
        return this.type;
    }
    //toString
    @Override
    public String toString(){
        return "Username: " + this.username + "\nPassword: [REDACTED]" + "\nType: " + this.type; 
    }
    
    private Account createTestAccount(){
        String Alpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        
        String testUsername;
        String testPassword;
        String testType;
        
        
        //random first name
        StringBuilder sbu = new StringBuilder(10);
        for(int i = 0; i < 10; i++){
            int index = (int)((int)Alpha.length() * Math.random());
            sbu.append(Alpha.charAt(index));
        }
        testUsername = sbu.toString();
        
        //random last name
        StringBuilder sbp = new StringBuilder(10);
        for(int i = 0; i < 10; i++){
            int index = (int)((int)Alpha.length() * Math.random());
            sbp.append(Alpha.charAt(index));
        }
        testPassword = sbp.toString();
        
        String[] typeList = {"Patient", "Hospital Employee", "Medical Professional", "Hospital Administrator"};
        testType = typeList[(int)(Math.random() * 5)];
        
        return new Account(testUsername, encrypt(testPassword, 5), testType);
    }
    
    private String signIn(String checkUsername, String checkPassword){
        try{
            System.out.println("reached");
            String decrypted = decrypt(this.password, 2);
            if(this.username.equals(checkUsername) && this.password.equals(checkPassword)){
                System.out.println("reached");
                return "Login Successful";

            }
            else if(this.username.equals(checkUsername) && decrypted != checkPassword){
                return "Password is incorrect, please try again.";
            }
            else if(this.username != checkUsername && (decrypted.equals(checkPassword) || decrypted != checkPassword)){
                return "Username does not exist, please try again or create an account";
            }
            else if(this.username == null && this.password == null){
                return "Please create an account to sign in.";
            }
            else{
                return null;
            }
        }
        catch(Exception e){
            return "Error Signing In, Please contact the support line!";
        }
        
    }
    
    private void signOut(){
        System.out.println("Goodbye, " + this.username + "!");
    }
    
    private String encrypt (String password, int shift){
        StringBuffer encrypted = new StringBuffer();
        
        for(int i = 0; i < password.length(); i++){
            if(Character.isUpperCase(password.charAt(i))){
                char c = (char)(((int)password.charAt(i) + shift - 65) % 26 + 65);
                encrypted.append(c);
            }
            else{
                char c = (char)(((int)password.charAt(i) + shift - 97) % 26 + 97);
                encrypted.append(c);
            }
        }
        return encrypted.toString();
    }
    private String decrypt (String password, int shift){
        return encrypt(password, (26-shift));
    }
}
