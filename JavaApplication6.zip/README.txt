ALPHACARE EARLY ALPHA

For M03-A04 Implemented Design Patterns, the patterns implemented can be found in these classes:

	Singleton Design Pattern: MainModel.java
	Dashboard UI Design Pattern: MainDashboardViewController.java and mainDashboardView.fxml

To currently run the application and reach the dashboard:
	1. Run the project and hit the Create button at the login window.
	2. Enter a username, password, and select Patient (Important this is the only functionality so far).
	3. Hit the Create button and a message saying your account has been created should appear, hit the Back button to go back into the Login window.
	4. Type in your newly created credentials, hit Login.
	5. Viola! You should now see the Dashboard UI with some light examples of where things will be placed.

Note: The UI included here is for Patients, other staff will have very similar but different UIs.
Note: User accounts are not persistent yet, you will need to make a burner account everytime you test it.

Please let me know if it does not run correctly or another issue persists. 

